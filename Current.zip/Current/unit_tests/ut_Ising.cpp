#include <iostream> 
#include <fstream>
#include <vector> 
#include <string> 
#include <map>
#include <random>
#include <chrono>
#include <getopt.h> 
#include <stdlib.h> 
#include "classes.h"
#include "misc.h"


int main(int argc, char** argv) {


    int opt; 
    int Nmov {-1}, dfreq {-1};
    std::string positions {"blank"}, topology {"blank"};  

    while ( (opt = getopt(argc, argv, ":f:N:p:t:h")) != -1 )
    {
        switch (opt) 
        {
            case 'f':
                // std::cout << "Option dreq was called with argument " << optarg << std::endl; 
                dfreq = atoi(optarg); 
                break;



            case 'N':
                // std::cout << "Option Nmov was called with argument " << optarg << std::endl; 
                Nmov = atoi(optarg); 
                break; 


            case 'h':
                std::cout << 
                "This is the main driver for the monte carlo simulation of polymers in a box.\n" <<
                "These are all the options we have available right now: \n" <<
                "help                     [-h]           (NO ARG REQUIRED)              Prints out this message. \n"<<
                "Dump Frequency           [-f]           (INTEGER ARGUMENT REQUIRED)    Frequency at which coordinates should be dumped out. \n"<<
                "Number of MC moves       [-N]           (INTEGER ARGUMENT REQUIRED)    Number of MC moves to be run on the system. \n" << 
                "Position coordinates     [-p]           (STRING ARGUMENT REQUIRED)     File with position coordinates\n" <<
                "Energy and geometry      [-t]           (STRING ARGUMENT REQUIRED)     File with energetic interactions and geometric bounds ie the topology\n"; 
                exit(EXIT_SUCCESS);
                break;


            case 'p':
                // std::cout <<"Option p was called with argument " << optarg << std::endl;
                positions = optarg;
                break;    

            case 't':
                topology = optarg; 
                break;


            case '?':
                std::cout << "ERROR: Unknown option " << static_cast<char>(optopt) << " was provided." << std::endl;
                exit(EXIT_FAILURE); 
                break;


            case ':':
                std::cout << "ERROR: Missing arg for " << static_cast <char> (optopt) << std::endl;
                exit(EXIT_FAILURE);
                break; 
        }
    }

    
    if (Nmov == -1 || dfreq == -1){
        std::cerr << "ERROR: No value for option N (number of MC moves to perform) and/or for option f (frequency of dumping) was provided. Exiting..." << std::endl;
        exit (EXIT_FAILURE);
    }
    else if (positions=="blank" || topology == "blank"){
        std::cerr << "ERROR: No value for option p (positions file) and/or for option t (energy and geometry file) was provided. Exiting..." << std::endl;
        exit (EXIT_FAILURE);    
    }

    
    // ---------------------------------------

    std::ofstream dump_file ("dumpfile.txt");
    dump_file.close(); 

    // ----------------------------------------

    /*~#~#~#~#~#~#~#~#~#~#~#~#~#~#~~#~#~#~#~#~#~#~#~#~#~#~#~
    ~#~#~#~#~#~#~#~#~#~#~#~#~#~#~~#~#~#~#~#~#~#~#~#~#~#~#~*/

    Grid G = CreateGridObject(positions, topology);

    G.instantiateOccupancyMap();
    
    G.CalculateEnergy();
    std::cout << "Energy of box is: " << G.Energy << std::endl;
    
    Grid G3 = IsingFlip(G) ; 


    std::cout << "On the surface..." << std::endl; 
    std::cout << "\n\nCoordinates of monomer unit of Polymer 0 in G are: " << std::endl;

    G.PolymersInGrid.at(0).printChainCoords();

    std::cout << "\n\nCoordinates of monomer unit of Polymer 0 in G3 are: " << std::endl;
    G3.PolymersInGrid.at(0).printChainCoords();    

    std::cout << "\n\n" << std::endl;

    std::cout << "\n\nCoordinates of monomer unit of Polymer 1 in G are: " << std::endl;

    G.PolymersInGrid.at(1).printChainCoords();

    std::cout << "\n\nCoordinates of monomer unit of Polymer 1 in G3 are: " << std::endl;
    G3.PolymersInGrid.at(1).printChainCoords();

    std::cout << "\n\n*~#~#~#~#~#~#~#~#~#~#~#~#~#~#~~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~#~~#~#~#~#~#~#~#~#~#~#~#~#~\n\n" << std::endl;

    std::cout << "This is my unit test." << std::endl;
    std::cout << "Check 1: Check number of elements in PolymersInGrid in both G and G3." << std::endl; 
    std::cout << "number of elements in PolymersInGrid in G is " << G.PolymersInGrid.size() << " and in G3 is " << G3.PolymersInGrid.size() << "." << std::endl;
    std::cout << "~#~#~#~#~#~#~#~#~#~#~#~#~#~#~~#~#~#~#~#~#~#~#~#~#~#~#~" << std::endl; 

    if (G.PolymersInGrid.size() != G3.PolymersInGrid.size() ){
        std::cerr << "Error in # of PolymersInGrid." << std::endl;
        exit(EXIT_FAILURE);
    }

    for (int i=0; i<G.PolymersInGrid.size(); i++){
        std::cout << "Check: Check number of elements in Polymers " << i << " in both G and G3." << std::endl; 
        std::cout << "Number of elements in Polymer " << i << " in G is " << G.PolymersInGrid.at(i).chain.size() 
        << " and in G3 is " << G3.PolymersInGrid.at(i).chain.size() << "." << std::endl; 
        std::cout << "~#~#~#~#~#~#~#~#~#~#~#~#~#~#~~#~#~#~#~#~#~#~#~#~#~#~#~" << std::endl; 
        if (G.PolymersInGrid.at(i).chain.size() != G3.PolymersInGrid.at(i).chain.size() ){
        std::cerr << "Error in # of monomers in Polymer "<< i << "." << std::endl;
        exit(EXIT_FAILURE);
        }
    }


    std::cout << "Check: Check number of elements in SolventInGrid in both G and G3." << std::endl; 
    std::cout << "number of elements in SolventInGrid in G is " << G.SolventInGrid.size() << " and in G3 is " << G3.SolventInGrid.size() << "." << std::endl;
    std::cout << "~#~#~#~#~#~#~#~#~#~#~#~#~#~#~~#~#~#~#~#~#~#~#~#~#~#~#~" << std::endl; 
    if (G.SolventInGrid.size() != G3.SolventInGrid.size() ){
        std::cerr << "Error in # of SolventInGrid." << std::endl;
        exit(EXIT_FAILURE);
    }

    std::cout << "Find discrepancy in PolymersInGrid." << std::endl; 
    for (int i=0; i<G.PolymersInGrid.size(); i++){
        for (int j=0; j<G.PolymersInGrid.at(i).chain.size(); j++){
            if (!(G.PolymersInGrid.at(i).chain.at(j) == G3.PolymersInGrid.at(i).chain.at(j)) ){
                std::cout << "\n\n---------------FOUND THE DISPLACED PARTICLE---------------" << std::endl;
                std::cout << "The orientation of the particle originally is " << G.PolymersInGrid.at(i).chain.at(j).orientation << std::endl;
                std::cout << "The orientation of the after is " << G3.PolymersInGrid.at(i).chain.at(j).orientation << std::endl;
                std::cout << "The position of the particle originally is ";
                print( G.PolymersInGrid.at(i).chain.at(j).coords ) ; 
                std::cout << "The position of the particle after is ";
                print( G3.PolymersInGrid.at(i).chain.at(j).coords ) ; 
                std::cout << "The type of the particle originally is " << G.PolymersInGrid.at(i).chain.at(j).ptype << std::endl;
                std::cout << "The type of the particle after is " << G3.PolymersInGrid.at(i).chain.at(j).ptype << std::endl;
                
                if (!(G.PolymersInGrid.at(i).chain.at(j).coords == G3.PolymersInGrid.at(i).chain.at(j).coords) ){
                    std::cerr << "There is a problem in location." << std::endl;
                    exit(EXIT_FAILURE);
                }
                else if (!(G.PolymersInGrid.at(i).chain.at(j).ptype == G3.PolymersInGrid.at(i).chain.at(j).ptype)) {
                    std::cerr << "There is a problem in type." << std::endl;
                    exit(EXIT_FAILURE);   
                }

            }
        }
    }
    std::cout << "\n\n"; 
    std::cout << "Find solvent particles..." << std::endl << std::endl;

    for (int i=0; i<G.SolventInGrid.size(); i++){
        if (G.SolventInGrid.at(i).orientation != G3.SolventInGrid.at(i).orientation){
            std::cout << "Orientations of particle are " << G.SolventInGrid.at(i).orientation << " and " << G3.SolventInGrid.at(i).orientation << std::endl; 
            print(G.SolventInGrid.at(i).coords);
            print(G3.SolventInGrid.at(i).coords) ;
        }
        if (! (G.SolventInGrid.at(i) == G3.SolventInGrid.at(i) )){
            std::cout << "Solvent discrepancy found!" << std::endl;
            std::cout << "The orientation of the particle originally is " << G.SolventInGrid.at(i).orientation << std::endl;
            std::cout << "The orientation of the after is " << G3.SolventInGrid.at(i).orientation << std::endl;
            std::cout << "The position of the particle originally is ";
            print( G.SolventInGrid.at(i).coords ) ; 
            std::cout << "The position of the particle after is ";
            print( G3.SolventInGrid.at(i).coords ) ; 
            std::cout << "The type of the particle originally is " << G.SolventInGrid.at(i).ptype << std::endl;
            std::cout << "The type of the particle after is " << G3.SolventInGrid.at(i).ptype << std::endl;
                
            if (!(G.SolventInGrid.at(i).coords == G3.SolventInGrid.at(i).coords) ){
                std::cerr << "There is a problem in location." << std::endl;
                exit(EXIT_FAILURE);
            }
            else if (!(G.SolventInGrid.at(i).ptype == G3.SolventInGrid.at(i).ptype)) {
                std::cerr << "There is a problem in type." << std::endl;
                exit(EXIT_FAILURE);   
            }
        }
    }

    std::cout << "\n\n";
    std::cout << "Printing connectivity map information \n\n"; 
    std::cout << "In the original case, G..." << std::endl;
    for (int i=0; i<G.PolymersInGrid.size(); i++){
        std::cout << "For Polymer " << i << ":" << std::endl;
        for (int j=0; j<G.PolymersInGrid.at(i).chain.size(); j++){

            // print out the particle and its connections 
            std::vector <Particle> pvec; 
            pvec = G.PolymersInGrid.at(i).ConnectivityMap[G.PolymersInGrid.at(i).chain.at(j)]; 
            std::cout << "The original particle is: ";
            print(G.PolymersInGrid.at(i).chain.at(j).coords ) ;
            std::cout << "The connections are: \n"; 
            for (auto v: pvec){
                print(v.coords); 
            } 

        }
        std::cout << "\n\n";
    }
    std::cout << "\n\nIn the MOVED case, G3..." << std::endl;
    for (int i=0; i<G3.PolymersInGrid.size(); i++){
        std::cout << "\n\nFor Polymer " << i << ":" << std::endl;
        for (int j=0; j<G3.PolymersInGrid.at(i).chain.size(); j++){

            // print out the particle and its connections 
            std::vector <Particle> pvec; 
            G3.PolymersInGrid.at(i).ChainToConnectivityMap();
            pvec = G3.PolymersInGrid.at(i).ConnectivityMap[G3.PolymersInGrid.at(i).chain.at(j)]; 
            std::cout << "The original particle is: ";
            print(G3.PolymersInGrid.at(i).chain.at(j).coords ) ;
            std::cout << "The connections are: \n"; 
            for (auto v: pvec){
                print(v.coords); 
            } 

        }
        std::cout << "\n\n";
    }    

    

    std::cout<<"\n\ntime for the main event: OccupancyMap." << std::endl << std::endl;

    for (std::map <std::vector <int>, Particle>::iterator iter=G.OccupancyMap.begin(); iter!=G.OccupancyMap.end(); ++iter){

        std::vector <int> key = iter->first; 

        if ( !(G.OccupancyMap[key] == G3.OccupancyMap[key]) ){
            
            std::cout << "The coordinates of the particle originally were: ";
            print(G.OccupancyMap[key].coords); 
            std::cout << "The coordinates of the particle after is: ";
            print(G3.OccupancyMap[key].coords);
            std::cout << "The orientation of the particle was " << G.OccupancyMap[key].orientation << std::endl;
            std::cout << "The orientation of the particle is " << G3.OccupancyMap[key].orientation << std::endl; 
            std::cout << "The particle type was " << G.OccupancyMap[key].ptype << std::endl;
            std::cout << "The particle type was " << G3.OccupancyMap[key].ptype << std::endl;

        }
            
    }
    
   

    return 0;


}