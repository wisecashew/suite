#!/bin/bash 

for T in 1 2 3 4 5
do 
	cp montecarlo.slurm Tequal${T}/.
done 
